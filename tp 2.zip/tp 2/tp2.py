#!/usr/bin/python

def loadCard( name, health, attack, cost):
    return {"name":name,"health":health,"attack":attack,"cost":cost}

def printCard(serviteur, displayMana):
    if displayMana == True:
        print(serviteur['name']+" ("+serviteur['attack']+"/"+serviteur['health']+") : "+serviteur['mana'])
    else:
        print(serviteur['name']+" ("+serviteur['attack']+"/"+serviteur['health']+")")

def fight(serviteur1, serviteur2):
    #Attaque du serviteur 1
    print(serviteur1['name']+" attaque....")
    serviteur2['health'] = serviteur2['health'] - serviteur1['attack']
    print(serviteur2['name']+" perd "+serviteur1["attack"]+" points de vie. ("+serviteur2['health']+")")
    #Attaque du serviteur 2
    print(serviteur2['name']+" attaque....")
    serviteur1['health'] = serviteur1['health'] - serviteur2['attack']
    print(serviteur1['name']+" perd "+serviteur2["attack"]+" points de vie. ("+serviteur1['health']+")")

def loadCardSet(nomFichier):
    fichier = open(nomFichier,'r')
    tabServiteur = [[]]
    for line in fichier:
        tmpTabLine = line.split(";")
        for i in len(tmpTabLine):
            if( isinstance(tmpTabLine, str) ):
                tmpTabLine[i] = tmpTabLine[i].replace("\n","")
                print(tmpTabLine[i])
        tabServiteur.append({"name":str(tmpTabLine[0]), "health":int(tmpTabLine[1]), "attack":int(tmpTabLine[2]), "cost":int(tmpTabLine[3])})
    return tabServiteur

def initPlayer(listeServiteur):
    joueur = {"health":30,"mana":1,"hand":listeServiteur,"field":None}
    return joueur

def playerTurn(player,ennemy):
    print("Tour du joueur "+player['name'])

def main():
    j1 = initPlayer(loadCardSet("deck1.txt"))
    j2 = initPlayer(loadCardSet("deck2.txt"))
    for card in j1['hand']:
        printCard(card,True)


if __name__ =='__main__':main()
    
    
